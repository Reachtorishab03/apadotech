<?php

/**
* Configuration Settings
**/

define('DB_HOST', 'localhost');
define('DB_NAME', 'cms');
define('DB_USER', 'cms_www');
define('DB_PASS', '2vJ651YkqC4gOqhr');

define('SMTP_HOST', 'mail.example.com');
define('SMTP_USER', 'user@example.com');
define('SMTP_PASS', 'secret');

define('SHOW_ERROR_DETAIL', true);
