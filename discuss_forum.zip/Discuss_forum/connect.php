<?php
mysql_connect('localhost','root','') or  die('cant connect database ');
mysql_select_db("forumseries") or die('cannot select database');
?> 